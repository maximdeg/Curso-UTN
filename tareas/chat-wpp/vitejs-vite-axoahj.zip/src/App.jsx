import React from 'react';
import './App.css';

function App() {
  return (
    <>
      <section className="header">
        <div>
          <button className="header-button-go-back">
            <i class="bi bi-arrow-left-circle"></i>
          </button>
        </div>
        <div className="header-user-picture">
          <img src="./images/pic.jpg" alt="" />
        </div>
        <div className="header-section-name">
          <span className="span-name">Nombre</span>
          <span className="span-description">Online</span>
        </div>
      </section>
      <section></section>

      <section className="text-area">
        <div>
          <textarea name="message" rows="5" cols="40">
            Aca va el texto
          </textarea>
          <button type="submit">
            <i class="bi bi-send-arrow-down-fill"></i>
          </button>
        </div>
      </section>
    </>
  );
}

export default App;
