import React from 'react';

function Header() {
  return (
    <header>
      <div>
        <button>Arrow back</button>
      </div>
      <div>
        <img src="../../images/pic.jpeg" alt="Profile Picture" />
      </div>
      <div>
        <span></span>
        <span></span>
      </div>
    </header>
  );
}

export default Header;
