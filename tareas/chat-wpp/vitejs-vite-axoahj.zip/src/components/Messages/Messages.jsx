import React from 'react';

function Messages() {
  return (
    <div>
      <p>ESTO ES UN MENSAJE</p>
    </div>
  );
}

export default Messages;
